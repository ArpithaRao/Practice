Main method is in MazeGeneration.java

Will have to open source files as a project files and run.